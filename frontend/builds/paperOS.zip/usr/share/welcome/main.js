let wnd = document.createElement("paperos-card");
wnd.setAttribute("applicationLocation", "/usr/share/welcome/index.html");
document.body.appendChild(wnd);
